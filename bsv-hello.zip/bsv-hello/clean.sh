#!/bin/bash

rm -f *.cxx *.o *.h *.ba *.bo *.so mkTest mkTest.v
